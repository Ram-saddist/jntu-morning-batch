import React from 'react'

export default function Patient() {
  return (
    <div>
      
    </div>
  )
}
