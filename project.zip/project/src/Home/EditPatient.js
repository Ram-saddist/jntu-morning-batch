import React from 'react'

export default function EditPatient() {
  return (
    <div>
      <button>edit</button>
    </div>
  )
}
