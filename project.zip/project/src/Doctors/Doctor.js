import React from 'react'

export default function Doctor() {
  return (
    <div>
      
    </div>
  )
}
